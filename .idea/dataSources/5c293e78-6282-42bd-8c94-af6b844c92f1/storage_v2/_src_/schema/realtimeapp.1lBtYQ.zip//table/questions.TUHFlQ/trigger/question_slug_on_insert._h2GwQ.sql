create definer = admin@`%` trigger question_slug_on_insert
	before INSERT
	on questions
	for each row
begin
            set new.slug = NAME_SLUG(NEW.title);
        end;

