create definer = admin@`%` trigger category_slug_on_update
	before UPDATE
	on categories
	for each row
begin
            set new.slug = NAME_SLUG(NEW.name);
        end;

