create definer = admin@`%` trigger category_slug_on_insert
	before INSERT
	on categories
	for each row
begin
            set new.slug = NAME_SLUG(NEW.name);
        end;

