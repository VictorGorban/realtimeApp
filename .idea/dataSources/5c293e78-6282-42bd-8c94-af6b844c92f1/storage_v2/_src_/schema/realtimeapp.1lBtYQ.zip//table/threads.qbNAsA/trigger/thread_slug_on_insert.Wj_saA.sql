create definer = admin@`%` trigger Thread_slug_on_insert
	before INSERT
	on threads
	for each row
begin
            set new.slug = NAME_SLUG(NEW.name);
        end;

